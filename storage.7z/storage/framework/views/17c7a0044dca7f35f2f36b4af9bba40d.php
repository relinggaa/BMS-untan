<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<style>
  video{
    width: 100%;
  }
</style>
<body>
  <?php if (isset($component)) { $__componentOriginal06decabcc5de0d0037e056c31da18b6d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06decabcc5de0d0037e056c31da18b6d = $attributes; } ?>
<?php $component = App\View\Components\Homenav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homenav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Homenav::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06decabcc5de0d0037e056c31da18b6d)): ?>
<?php $attributes = $__attributesOriginal06decabcc5de0d0037e056c31da18b6d; ?>
<?php unset($__attributesOriginal06decabcc5de0d0037e056c31da18b6d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06decabcc5de0d0037e056c31da18b6d)): ?>
<?php $component = $__componentOriginal06decabcc5de0d0037e056c31da18b6d; ?>
<?php unset($__componentOriginal06decabcc5de0d0037e056c31da18b6d); ?>
<?php endif; ?>
  <div class="container-fluid">
    <video class="video-bg" autoplay loop muted >
      <source src="/img/video.MOV" type="video/mp4">
      Your browser does not support the video tag.
    </video>
  </div>
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BMS-untan\resources\views/pilih-login.blade.php ENDPATH**/ ?>